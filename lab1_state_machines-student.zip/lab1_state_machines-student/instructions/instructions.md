# Lab 1 - State Machines

Welcome to lab 1! This lab will introduce you to the hardware we use and to the C/C++ SDK provided by Rasbperry Pi for the Pico board. 

## Requirements 

For this lab you will need the **Maker Pi Pico** board that is part of your **lab kit**. In addition, you will need the SDK and an ARM development toolchain. You have two different options there: 

- Use preinstalled VM on one of the lab computers
- Install the toolchain on your own machine 

For installation instructions follow the guidelines as outlined in [Getting started with Raspberry Pi Pico](https://datasheets.raspberrypi.com/pico/getting-started-with-pico.pdf). Installation instructions for Linux are in Chapter 2, for macOS and Windows in Appendix A. 

If you want to use your own computer, you may also wish to install **VSCode** for developing, and **OpenOCD** for debugging, which are outlined in Chapters 5 and 7 respectively. 
You may have to adapt the values in ./vscode/c_cpp_properties.json if you work on your own machine. In the provided VM it should point to the correct location already. 

**If you use your own machine and the compilation step fails, doublecheck that you have set the `PICO_SDK_PATH` environment variable!**

## Template 

To get you started, please download the template for lab 1 from Studium! Look through the code and try to understand it. Most of your work will happen in main.c, but you may have to adapt CMakeLists.txt as well. 

**You may use some of the code you have already seen during the lecture! It is located under Files/Code on Studium!** 

## Debugging 

If you want to step through your code, you can connect your board to a debugger. For this you will need the second Pico board that is part of your lab kit. You can find the wiring diagram and setup in [Getting started with Raspberry Pi Pico](https://datasheets.raspberrypi.com/pico/getting-started-with-pico.pdf) in Appendix A. We have already included settings in the template that should allow you to use the VSCode debugging features! 

## Goal 

At the end of this lab you will have implemented a state machine with various states, each of which is determined by a different light pattern shown through the LEDs on the development board. State changes are triggered by button presses. The overall state machine is illustrated below: 

![Image](lab1_statemachine.png) 

As can be seen, there are three different states. The first and second button on the board (GP20, GP21) are used to switch between these states in a clockwise (respectively counter clockwise) manner. The different states are defined as follows: 

When the system is in state **S0** it will display a light rope on the first 4 LEDs (GP0 - GP3), i.e. LED1 will light up, after a short while it will turn off and LED2 will turn on, etc. In **S1** all LEDs will turn on for a while, and then all will turn off, this behaviour is repeated (i.e. you will blink all LEDs). **S2** is the same as **S0**, but in the other direction and faster. 

## Part 1 

If you inspect the code, you will find that in the beginning we define some custom types, which we will use for our application. In part 1 of this lab we will only deal with the first state, **S0**. If we look at the type specification for a state

```C 
typedef void (*state_func_t)( void );

typedef struct _state_t
{
    uint8_t id;
    state_func_t Enter;
    state_func_t Do;
    state_func_t Exit;
    uint32_t delay_ms;
} state_t;
```
we can see, that each state has an ID, three different fuctions that are called when entering, executing, and exiting the state, and a delay, which will determine how often we check for a button input. To make it easier for you, in the template we have already provided you with the function signature for the executing state function (`void do_state_0( void )`), and also included parts of the execution routine in the main function. As a first step, implement the three different functions for the first state. When you have implemented your state functions, fill out the `const state_t state0` declaration given further down in the file. 

Think of a good value for the delay, so that you can clearly see the light rope (also consider that when implementing **S2**, you will need to make that one faster, so you should give yourself some margin here). When you have implemented the state0 variable, you can turn to the main function, and finish it in a very basic implementation that calls the appropriate state functions at appropriate times. 
You can now compile your code by issuing 

```bash
mkdir build
cd build
cmake ..
make
```

on the terminal. When your program has compiled you can upload it to your connected board by copying the file onto the USB device. 

Hints: **The implementation of the Do function must not use any form of delay or loop!**

## Part 2 

For this part you will implement the other two states and also the state changing mechanism. For this, start by implementing the state functions, and also the state declarations according to how you've done it in the first part. Once you are finished, fill out the state table `const state_t state_table[][]` in the code. Observe, that you need to include a possible transition for each event type that you have defined, even if in your current state, you do not adhere to certain inputs. In those cases, the state should remain the same, i.e. you can put the current state in those columns (one such case is for the no_evt, which signals that no input was received).

Now that you have implemented the states, you also need to implement the state transitions. For this, implement button debouncing as seen during the lecture. The communication between your button event handler and your main function can be done in different ways. We suggest to use the queue library of the SDK as seen during the lecture. Make sure to use a proper button debounce delay! For better readability you can also implement a function `event_t get_event(void)` that looks if there is a new data element in the queue and returns the appropriate event. This function can then be used in the main function to determine if a state change needs to happen. 
You will also have to update the execution mechanism in the main function. For reference, you might want to consult the lecture slides about the traffic lights example again. 

## Part 3

By now you have a functioning state machine, which allows you to switch between different light patterns by pressing the first and second button on your board. Maybe you think, that implementing the state machine in the table driven way was a bit of an overkill for this example, and you are right, this could have also been done in a different (probably easier) way. However, to see why table driven implementations are quite powerful, we will now introduce a new state **S3**. This state is entered whenever you are in any of the other states, and press button 3. In this state, the first LED will slowly fade between full brightness and being turned off. Upon any button press it shall continue with state **S0**. To implement this, you will need to make use of the pwm library. 

Hints: You may have to include something in CMakeLists.txt for this! 

**When you are finished with all parts show the solution to one of the teachers! Once we have approved it you also have to upload it to Studium!** 

